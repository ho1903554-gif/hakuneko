export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'f5984f',
        link: 'https://github.com/manga-download/hakuneko/commits/f5984f9ba79fb011ae598686ffed052adcb7a594',
    }
};